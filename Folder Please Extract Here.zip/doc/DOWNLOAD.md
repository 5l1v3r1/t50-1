Download and Installing {#download}
=======================

Download T50 source code from sourceforge at http://t50.sf.net or from GitLab at http:://gitlab.com/fredericopissarra/t50

To compile and install just do:

<pre>
  $ make
  $ sudo make install</pre>

To run t50 you'll need to have root privileges. For instance:

<pre>  $ sudo t50 --threshold 10 10 192.168.10.3</pre>
